<html>
<head>
<title>MG!</title>
<script>
</script>
</head>
<body>
<?php

print('Merhaba Gursu!<br>');

?>
Saat: <?=date('H:i:s')?>
</body>
</html>
